package com.truly.chaybo

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var service: RunnerService? = null
    private var pageReady = false
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = (binder as RunnerService.LocalBinder).service()
            service = s
            s.listener = { json ->
                runOnUiThread { web.evaluateJavascript("window.onState && window.onState($json)", null) }
            }
            notifyReadyIfPossible()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                notifyReadyIfPossible()
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        // Giữ Service sống độc lập với Activity (khi bắt đầu tập sẽ chuyển sang foreground)
        bound = bindService(Intent(this, RunnerService::class.java), connection, Context.BIND_AUTO_CREATE)
    }

    private fun notifyReadyIfPossible() {
        if (pageReady && service != null) {
            runOnUiThread { web.evaluateJavascript("window.nativeReady && window.nativeReady()", null) }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Quay lại = thu nhỏ app, buổi tập vẫn chạy ngầm
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        service?.listener = null
        if (bound) {
            unbindService(connection)
            bound = false
        }
        web.destroy()
        super.onDestroy()
    }

    /** Cầu nối JavaScript <-> Service. Giao diện gọi qua đối tượng `Android`. */
    inner class Bridge {
        @JavascriptInterface
        fun setPlaylist(json: String) { service?.setPlaylist(json) }

        @JavascriptInterface
        fun toggle() {
            val i = Intent(this@MainActivity, RunnerService::class.java).setAction(RunnerService.ACTION_TOGGLE)
            startForegroundService(i)
        }

        @JavascriptInterface
        fun jump(idx: Int) { service?.jump(idx) }

        @JavascriptInterface
        fun testVoice() { service?.testVoice() }

        @JavascriptInterface
        fun getState(): String = service?.getStateJson() ?: "{}"

        @JavascriptInterface
        fun openTtsSettings() {
            try {
                startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
}
