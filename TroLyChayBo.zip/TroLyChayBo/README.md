# Trợ Lý Chạy Bộ Toàn Diện (Android)

Kiến trúc: WebView (giao diện HTML offline) + Foreground Service (mediaPlayback)
+ PARTIAL_WAKE_LOCK + Android TextToSpeech vi-VN + JavaScript Bridge (`Android`).

## Cách build APK
1. Cài Android Studio (Koala trở lên), chọn **Open** -> thư mục này.
2. Chờ Gradle sync (cần mạng lần đầu). Nếu hỏi Gradle wrapper, chọn dùng Gradle 8.7+.
3. Cắm Samsung Galaxy A17 (bật USB debugging) -> bấm **Run**,
   hoặc **Build > Build APK(s)** rồi chép file `app-debug.apk` vào máy để cài.

## Trước khi đi tập
- Cấp quyền **Thông báo** khi app hỏi (để thấy nút Tạm dừng/Tiếp tục trên thanh trạng thái).
- Cài giọng tiếng Việt: Cài đặt > Quản lý chung > Chuyển văn bản thành giọng nói
  (Google TTS > tải dữ liệu "Tiếng Việt"). App sẽ cảnh báo nếu chưa có.
- Samsung: Cài đặt > Pin > Giới hạn sử dụng nền > thêm app vào "Ứng dụng không bao giờ ngủ".

## Cấu trúc
- `app/src/main/java/com/truly/chaybo/RunnerService.kt` – bộ đếm giờ, TTS, WakeLock, thông báo.
- `app/src/main/java/com/truly/chaybo/MainActivity.kt` – WebView + cầu nối JS.
- `app/src/main/assets/index.html` – giao diện (không cần Internet).
